var button1 = document.getElementById("asend");
button1.onclick = asendnums;

function asendnums(){
  var input = document.getElementById("numbers").value;
  var numarray = input.split(" ");
  if (!numarray.some(isNaN)){
    numarray.sort((a,b)=>a-b);alert(numarray);
    }else {
      alert("Error! Not all inputs are numbers.")
    }
}

var button2 = document.getElementById("desend");
button2.onclick = desendnums 

function desendnums(){
  var input = document.getElementById("numbers").value;
  var numarray = input.split(" ");
  if (!numarray.some(isNaN)){
  numarray.sort((a,b)=>b-a);
  alert(numarray);
  }else {
    alert("Error! Not all inputs are numbers.")
  }
}

//button1.onclick = ordernums;
//x = [c b a];
//alert(x);

//button2.onclick = ordernums;
//x = [a b c];
//alert(x);


// function ordernums(){}
  // a = numarray(1);
  // b = numarray(2);
  // c = numarray;
  // if (b>a && b>c){
      //a = b;
      //b = nums(1);
      //}if (c>b){
         //c = b;
         //b = nums(3);
          //}
  // if (c>a && c>b){
      //a = c;
      //c = nums(1);
      //}if (c>b){
         //b = c;
          //b = nums(2);
          //}
  // if (c>b){
    //b = c;
    //c = nums(2);
    //}
// }

